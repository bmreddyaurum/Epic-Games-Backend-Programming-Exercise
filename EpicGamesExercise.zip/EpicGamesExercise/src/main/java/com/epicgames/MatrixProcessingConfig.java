package com.epicgames;

/**
 * The {@code MatrixProcessingConfig} class contains various configuration constants
 * and utility classes that are used throughout the matrix processing application.
 * This class is marked as final and has a private constructor to prevent instantiation.
 */
public final class MatrixProcessingConfig {
    private MatrixProcessingConfig() {
    } // Prevent instantiation

    /**
     * Commands available for matrix processing.
     */
    public enum Command {
        QUIT("Q");

        private final String value;

        Command(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    /**
     * Configurations related to matrix size limitations.
     */
    public static final class Limits {
        public static final int MAX_MATRIX_SIZE = 1000;

        private Limits() {
        }
    }

    /**
     * User interface messages for matrix processing.
     */
    public static final class Messages {
        public static final String INPUT_PROMPT =
                "****************************************************************************************\nEnter matrix rows (columns separated by comma && rows separated by new line(press enter)).";
        public static final String FINISH_PROMPT =
                "Enter new line(press enter) to finish current matrix, or 'Q|q' to exit.";
        public static final String MATRIX_COMPLETION_MESSAGE =
                "### Matrix completed. Enter another matrix, or type 'Q|q' to exit. ###\n\n";
        public static final String INVALID_MATRIX_MESSAGE =
                "Invalid entries, all rows must have the same number of columns/elements!";
        public static final String INVALID_MATRIX_SIZE =
                "Matrix exceeds maximum size limit.";
        public static final String INVALID_INPUT_MESSAGE =
                "Invalid input. Please enter only integers separated by commas.";

        private Messages() {
        }
    }

    /**
     * Format specifications for matrix input/output.
     */
    public static final class Format {
        public static final String ELEMENT_DELIMITER = ", ";

        private Format() {
        }
    }
}