package com.epicgames;

import com.epicgames.util.CommonUtil;
import com.epicgames.util.LogUtil;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * The {@code ProcessMatrices} class provides functionality to read, validate,
 * and process matrices through console input. It supports checking the validity
 * of matrix structures, parsing row data, and processing matrices for specific
 * operations such as spiral traversals.
 */
public class ProcessMatrices {
    private static final Logger logger = LogUtil.getLogger(ProcessMatrices.class);

    private static List<int[]> readMatrixInput(BufferedReader reader) throws IOException {
        List<int[]> rows = new ArrayList<>();

        while (true) {
            String line = reader.readLine();
            if (line == null) return null; // End of input stream

            line = line.trim();
            if (line.equalsIgnoreCase(MatrixProcessingConfig.Command.QUIT.getValue())) {
                logger.info("Quitting processing.");
                System.out.println("Quitting.");
                rows.clear();
                return null;
            }

            if (line.isEmpty()) {
                if (!rows.isEmpty()) {
                    // If we have at least one valid row, empty line signals completion
                    return rows;
                }
                continue; // Skip empty lines before first valid row
            }

            try {
                int[] row = parseRow(line);
                if (row.length == 0) {
                    logger.warn("Empty row detected, skipping.");
                } else {
                    rows.add(row);

                }

            } catch (NumberFormatException ex) {
                System.err.println(MatrixProcessingConfig.Messages.INVALID_INPUT_MESSAGE);
                logger.error(MatrixProcessingConfig.Messages.INVALID_MATRIX_MESSAGE);
            }
        }
    }


    /**
     * Parses a single line of comma-separated integers into an array of integers.
     * The method trims whitespace from the individual elements and converts them to integers.
     *
     * @param line a string containing comma-separated integer values
     * @return an array of integers parsed from the input string
     * @throws NumberFormatException if any of the elements cannot be converted to an integer
     */
    private static int[] parseRow(String line) {
        return Arrays.stream(line.split(","))
                .map(String::trim)
                .mapToInt(Integer::parseInt)
                .toArray();
    }

    /**
     * Processes the given matrix by displaying its contents and calculating the result
     * of its spiral traversal. The method also logs output and computes the time taken for traversal.
     *
     * @param matrix a 2D integer array representing the matrix to be processed
     *               The matrix is expected to be non-null and rectangular (all rows should have the same length).
     */
    private static void processAndDisplayMatrix(int[][] matrix) {
        StringBuilder output = new StringBuilder(matrix.length * 20);
        System.out.println("Matrix read from console:");
        for (int[] row : matrix) {
            output.append(Arrays.toString(row)).append("\n");
        }
        System.out.println(output);

        MatrixSpiralTraversal matrixSpiralTraversal = new MatrixSpiralTraversal();
        CommonUtil.startTimer();
        String result = matrixSpiralTraversal.traverseSpiral(matrix);
        System.out.println("Matrix results: " + result);
        long resultTime = CommonUtil.timeTaken();
        CommonUtil.stopWatchReset();

        logger.info("Matrix read from console:\n{}", output);
        logger.info("Matrix results: {}", result);
        logger.info("Time taken: {}", resultTime);
        //System.out.printf("Time taken: %d ms \n", resultTime);
    }

    /**
     * Validates whether the given 2D integer array represents a valid matrix.
     * A valid matrix is non-null, has at least one row and column, is rectangular
     * (all rows must have the same number of columns), and does not exceed the
     * maximum allowed size.
     *
     * @param matrix the 2D integer array to validate
     * @return {@code true} if the matrix is valid, {@code false} otherwise
     */
    public boolean isValidMatrix(int[][] matrix) {
        if (matrix == null || matrix.length == 0 || matrix[0] == null || matrix[0].length == 0) {
            System.err.println(MatrixProcessingConfig.Messages.INVALID_MATRIX_MESSAGE);
            logger.error(MatrixProcessingConfig.Messages.INVALID_MATRIX_MESSAGE);
            return false;
        }
        if (matrix.length > MatrixProcessingConfig.Limits.MAX_MATRIX_SIZE) {
            System.err.println(MatrixProcessingConfig.Messages.INVALID_MATRIX_SIZE);
            logger.error(MatrixProcessingConfig.Messages.INVALID_MATRIX_SIZE);
            return false;
        }
        int expectedColumns = matrix[0].length;
        for (int i = 1; i < matrix.length; i++) {
            if (matrix[i] == null || matrix[i].length != expectedColumns) {
                System.err.println(MatrixProcessingConfig.Messages.INVALID_MATRIX_MESSAGE);
                logger.error(MatrixProcessingConfig.Messages.INVALID_MATRIX_MESSAGE);
                return false;
            }
        }
        return true;
    }

    /**
     * Reads, validates, and processes matrices input from the user via the provided BufferedReader.
     * The method continuously prompts for input until the user explicitly quits or provides invalid input.
     * Valid matrices are processed and displayed along with their results.
     *
     * @param reader the {@code BufferedReader} to read user input from. Each line can either represent a row
     *               of the matrix (as comma-separated integers) or a command to quit processing.
     * @throws IOException if an I/O error occurs while reading input from the BufferedReader.
     */
    public void processMatrices(BufferedReader reader) throws IOException {
        try {
            while (true) {
                System.out.println(MatrixProcessingConfig.Messages.INPUT_PROMPT);
                System.out.println(MatrixProcessingConfig.Messages.FINISH_PROMPT);

                List<int[]> matrixRows = readMatrixInput(reader);
                if (matrixRows == null) {
                    return;
                }

                if (!matrixRows.isEmpty()) {
                    int[][] matrix = matrixRows.toArray(new int[0][]);
                    if (isValidMatrix(matrix)) {
                        processAndDisplayMatrix(matrix);
                        System.out.println(MatrixProcessingConfig.Messages.MATRIX_COMPLETION_MESSAGE);
                    }
                }

            }
        } catch (Exception e) {
            logger.error("Error processing matrices", e);
            throw e;
        }
    }
}