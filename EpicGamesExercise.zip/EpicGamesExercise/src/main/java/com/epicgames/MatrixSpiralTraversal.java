package com.epicgames;

import com.epicgames.util.LogUtil;
import org.slf4j.Logger;

import java.util.StringJoiner;

/**
 * The MatrixSpiralTraversal class provides functionality to traverse a two-dimensional
 * matrix in a spiral order and return the elements in a formatted string.
 * It validates the matrix for constraints such as size and integrity before traversal.
 */
public class MatrixSpiralTraversal {
    private static final Logger logger = LogUtil.getLogger(MatrixSpiralTraversal.class);

    /**
     * Traverses the input matrix in spiral order and returns the elements as a delimited string.
     *
     * @param matrix the input matrix to traverse
     * @return a string containing matrix elements in spiral order, or empty string if input is invalid
     * @throws IllegalArgumentException if the matrix is ragged (has rows of different lengths)
     */
    public String traverseSpiral(int[][] matrix) {

        if (matrix == null || matrix.length == 0 || matrix[0] == null || matrix[0].length == 0) {
//            System.err.println(MatrixProcessingConfig.Messages.INVALID_MATRIX_MESSAGE);
//            logger.error(MatrixProcessingConfig.Messages.INVALID_MATRIX_MESSAGE);
            return "";
        }
        if (matrix.length > MatrixProcessingConfig.Limits.MAX_MATRIX_SIZE) {
            System.err.println(MatrixProcessingConfig.Messages.INVALID_MATRIX_SIZE);
            logger.error(MatrixProcessingConfig.Messages.INVALID_MATRIX_SIZE);
            return "";
        }

        StringJoiner result = new StringJoiner(MatrixProcessingConfig.Format.ELEMENT_DELIMITER);
        int rows = matrix.length;
        int cols = matrix[0].length;

        MatrixBoundary boundary = new MatrixBoundary(rows, cols);

        while (boundary.hasMoreElements()) {
            traverseRight(matrix, boundary, result);
            traverseDown(matrix, boundary, result);
            traverseLeft(matrix, boundary, result);
            traverseUp(matrix, boundary, result);
        }

        return result.toString();
    }


    /**
     * Traverses the given matrix in a rightward direction within the specified boundaries
     * and appends the elements encountered to the provided result.
     *
     * @param matrix   the input two-dimensional array representing the matrix
     * @param boundary the current boundaries within which the rightward traversal is performed
     * @param result   the StringJoiner object to which the traversed elements are appended
     */
    private void traverseRight(int[][] matrix, MatrixBoundary boundary, StringJoiner result) {
        for (int j = boundary.left; j <= boundary.right; j++) {
            result.add(String.valueOf(matrix[boundary.top][j]));
        }
        boundary.top++;
    }

    /**
     * Traverses the given matrix in a downward direction within the specified boundaries
     * and appends the elements encountered to the provided result.
     *
     * @param matrix   the input two-dimensional array representing the matrix
     * @param boundary the current boundaries within which the downward traversal is performed
     * @param result   the StringJoiner object to which the traversed elements are appended
     */
    private void traverseDown(int[][] matrix, MatrixBoundary boundary, StringJoiner result) {
        for (int i = boundary.top; i <= boundary.bottom; i++) {
            result.add(String.valueOf(matrix[i][boundary.right]));
        }
        boundary.right--;
    }

    /**
     * Traverses the given matrix in a leftward direction within the specified boundaries
     * and appends the elements encountered to the provided result.
     *
     * @param matrix   the input two-dimensional array representing the matrix
     * @param boundary the current boundaries within which the leftward traversal is performed
     * @param result   the StringJoiner object to which the traversed elements are appended
     */
    private void traverseLeft(int[][] matrix, MatrixBoundary boundary, StringJoiner result) {
        if (boundary.top <= boundary.bottom) {
            for (int j = boundary.right; j >= boundary.left; j--) {
                result.add(String.valueOf(matrix[boundary.bottom][j]));
            }
            boundary.bottom--;
        }
    }

    /**
     * Traverses the given matrix in an upward direction within the specified boundaries
     * and appends the elements encountered to the provided result.
     *
     * @param matrix   the input two-dimensional array representing the matrix
     * @param boundary the current boundaries within which the upward traversal is performed
     * @param result   the StringJoiner object to which the traversed elements are appended
     */
    private void traverseUp(int[][] matrix, MatrixBoundary boundary, StringJoiner result) {
        if (boundary.left <= boundary.right) {
            for (int i = boundary.bottom; i >= boundary.top; i--) {
                result.add(String.valueOf(matrix[i][boundary.left]));
            }
            boundary.left++;
        }
    }

    /**
     * Represents the boundaries of a matrix during traversal.
     * The boundaries define the current limits for rows and columns
     * that can be accessed during iterative traversal operations.
     */
    private static class MatrixBoundary {
        int top;
        int bottom;
        int left;
        int right;

        /**
         * Constructs a MatrixBoundary object with the specified number of rows and columns.
         * Initializes the boundaries for matrix traversal.
         *
         * @param rows the total number of rows in the matrix
         * @param cols the total number of columns in the matrix
         */
        MatrixBoundary(int rows, int cols) {
            this.top = 0;
            this.bottom = rows - 1;
            this.left = 0;
            this.right = cols - 1;
        }

        /**
         * Determines whether there are more elements to process based on the current
         * boundaries of a matrix traversal.
         *
         * @return true if the current boundaries allow additional elements to be
         * traversed (i.e., the top boundary is less than or equal to the
         * bottom boundary, and the left boundary is less than or equal to
         * the right boundary); false otherwise.
         */
        boolean hasMoreElements() {
            return top <= bottom && left <= right;
        }
    }
}