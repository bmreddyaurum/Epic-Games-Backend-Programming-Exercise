package com.epicgames.util;

import org.apache.commons.lang3.time.StopWatch;

/**
 * Utility class for managing a stopwatch timer for measuring time intervals.
 * Provides methods to start the timer, retrieve the elapsed time, and reset the stopwatch.
 */
public class CommonUtil {
    public static StopWatch stopWatch = new StopWatch();


    /**
     * Starts the stopwatch timer.
     * This method begins timing a specific operation by invoking the start method
     * on the shared {@code StopWatch} instance. It acts as a utility to measure
     * the execution time of a block of code or operation.
     * <p>
     * Note: Ensure to stop the stopwatch using {@code CommonUtil.timeTaken()} or
     * reset it via {@code CommonUtil.stopWatchReset()} to avoid incorrect
     * timing measurements in consecutive operations.
     */
    public static void startTimer() {
        stopWatch.start();
    }

    /**
     * Stops the shared stopwatch instance and retrieves the elapsed time in milliseconds.
     * This method is used to measure the time taken for an operation between the
     * start and stop of the stopwatch.
     *
     * @return the elapsed time in milliseconds as a long value
     */
    public static long timeTaken() {
        stopWatch.stop();
        return stopWatch.getTime();
    }

    /**
     * Resets the shared stopwatch instance.
     * This method is used to clear the state of the stopwatch by invoking
     * its reset method, preparing it for a new timing operation.
     * <p>
     * It is typically called after stopping the stopwatch and retrieving the
     * elapsed time, ensuring accurate measurements for subsequent operations.
     */
    public static void stopWatchReset() {
        stopWatch.reset();
    }

}
