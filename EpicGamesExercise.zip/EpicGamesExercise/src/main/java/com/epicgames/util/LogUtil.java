package com.epicgames.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class for creating and managing logger instances using SLF4J.
 * <p>
 * This class provides a static method to fetch a logger instance associated with a specific class.
 * The logger can then be used for logging messages, errors, or other debugging information.
 * <p>
 * Instantiation of this class is prohibited as it is designed to be a utility class.
 */
public class LogUtil {
    private LogUtil() {
        // Prevent instantiation
    }

    /**
     * Retrieves a logger instance associated with the specified class.
     * This logger can be used for logging messages, errors, and other information
     * related to the given class.
     *
     * @param clazz the class for which the logger instance is to be created
     * @return a logger instance for the specified class
     */
    public static Logger getLogger(Class<?> clazz) {
        return LoggerFactory.getLogger(clazz);
    }
}