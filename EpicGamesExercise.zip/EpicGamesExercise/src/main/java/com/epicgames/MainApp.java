package com.epicgames;

import com.epicgames.util.LogUtil;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


/**
 * The {@code MainApp} class serves as the entry point for the application. It initializes
 * resources, manages exception handling, and coordinates the matrix processing tasks
 * through the {@code ProcessMatrices} class.
 * <p>
 * The application reads matrix data from standard input, processes it using the
 * {@code ProcessMatrices} utility, and handles various types of runtime exceptions
 * including I/O errors, invalid input formats, and unexpected application errors.
 * <p>
 * Logging is used extensively to track errors and application flow.
 */
public class MainApp {
    private static final Logger logger = LogUtil.getLogger(MainApp.class);

    public static void main(String[] args) {


        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            ProcessMatrices processMatrices = new ProcessMatrices();
            processMatrices.processMatrices(reader);
        } catch (IOException e) {
            logger.error("Error reading input", e);
        } catch (NumberFormatException e) {
            logger.error("Invalid number format in input", e);
        } catch (IllegalArgumentException e) {
            logger.error("Invalid matrix configuration", e);
        } catch (Exception e) {
            logger.error("Unexpected error during matrix processing", e);
        } finally {
            logger.info("Application finished.");
        }
    }


}