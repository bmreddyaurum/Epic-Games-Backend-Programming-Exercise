package com.epicgames;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for verifying the operations and functionalities of matrix-related logic.
 * Contains nested test cases for different scenarios, including edge cases, linear matrices,
 * square matrices, and rectangular matrices.
 * Relies on the MatrixSpiralTraversal and ProcessMatrices classes for core validations
 * and traversal logic.
 *
 * Uses JUnit 5 for testing with specific methods annotated to assert outcomes
 * for various matrix inputs and edge conditions.
 */
@DisplayName("Matrix Operations Tests")
class ProcessMatricesAndMatrixSpiralTraversalTest {
    private static final int[][] SINGLE_ELEMENT_MATRIX = {{9}};
    private static final int[][] MATRIX_1X4 = {{1, 2, 3, 4}};
    private static final int[][] MATRIX_4X1 = {{1}, {2}, {3}, {4}};
    private static final int[][] MATRIX_2X2 = {
            {1, 2},
            {3, 4}
    };
    /**
     * A constant 3x3 matrix used for testing and validation purposes.
     * The matrix contains sequential integers arranged in rows.
     *
     * Structure:
     * Row 1: {1, 2, 3}
     * Row 2: {4, 5, 6}
     * Row 3: {7, 8, 9}
     */
    private static final int[][] MATRIX_3X3 = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
    };

    /**
     * A constant 3x4 matrix represented as a 2D integer array.
     *
     * This matrix is defined with three rows and four columns, and is initialized
     * with sequential integer values starting from 1. The structure of the matrix
     * is as follows:
     *
     * Row 1: {1, 2, 3, 4}
     * Row 2: {5, 6, 7, 8}
     * Row 3: {9, 10, 11, 12}
     *
     * This constant is used for testing and validating matrix-related operations
     * such as traversal and processing within the associated test cases.
     */
    private static final int[][] MATRIX_3X4 = {
            {1, 2, 3, 4},
            {5, 6, 7, 8},
            {9, 10, 11, 12}
    };
    /**
     * A static 4x3 matrix represented as a two-dimensional array of integers.
     *
     * MATRIX_4X3 contains predefined values arranged in four rows and three columns:
     *
     * Row 1: {1, 2, 3}
     * Row 2: {4, 5, 6}
     * Row 3: {7, 8, 9}
     * Row 4: {10, 11, 12}
     *
     * This matrix can be used for testing or demonstrating operations on
     * 4x3 matrices such as traversal, validation, and other matrix-related processes.
     */
    private static final int[][] MATRIX_4X3 = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9},
            {10, 11, 12}
    };
    /**
     * A static 2D integer array representing a matrix where rows have uneven lengths.
     *
     * This matrix is used primarily for testing scenarios related to the validation
     * of matrix structures, specifically to verify the behavior of methods handling
     * matrices with rows of varying lengths. Such matrices are typically considered
     * invalid in contexts requiring uniform row lengths.
     *
     * Example configuration:
     * - The first row contains 3 elements: {1, 2, 3}.
     * - The second row contains 2 elements: {5, 6}.
     * - The third row contains 4 elements: {9, 10, 11, 12}.
     *
     * Constant across test executions and immutable at runtime.
     */
    private static final int[][] UNMATCHED_ROWS_MATRIX = {
            {1, 2, 3},
            {5, 6},
            {9, 10, 11, 12}
    };

    /**
     * Represents an instance of the MatrixSpiralTraversal class, which provides
     * functionality for traversing a matrix in spiral order.
     *
     * This variable is used for testing spiral traversal operations on various
     * input matrices, converting matrix data into a string in a spiral sequence.
     *
     * The MatrixSpiralTraversal object encapsulates traversal logic and ensures
     * that the provided matrix conforms to the required constraints (e.g., all rows
     * must have the same number of columns).
     */
    private MatrixSpiralTraversal traversal;
    /**
     * Represents an instance of the {@code ProcessMatrices} class,
     * used for reading, validating, and processing matrices represented as 2D integer arrays.
     * This variable is utilized for matrix-related functionalities such as validation,
     * parsing input rows, and performing operations like spiral traversal on matrices.
     */
    private ProcessMatrices processMatrices;

    /**
     * Sets up the test environment before each test case is executed.
     * Initializes instances of the MatrixSpiralTraversal and ProcessMatrices
     * classes, which are required for testing their respective functionalities.
     */
    @BeforeEach
    void setUp() {
        traversal = new MatrixSpiralTraversal();
        processMatrices = new ProcessMatrices();
    }

    /**
     * Test suite for validating edge cases related to matrix traversal and validation functionality.
     * This class contains tests to ensure the robustness of the `traverseSpiral` and `isValidMatrix` methods
     * against edge case inputs such as empty matrices, single-element matrices, and irregular matrices.
     */
    @Nested
    @DisplayName("Edge Cases")
    class EdgeCasesTests {
        /**
         * Validates the behavior of the `traverseSpiral` method when invoked on a matrix
         * with an empty first row.
         *
         * This test ensures that the method correctly handles the edge case by
         * returning an empty string, as there are no elements to traverse.
         *
         * Assertions:
         * - Verifies that calling `traverseSpiral` with a matrix containing an
         *   empty first row results in an empty string being returned.
         */
        @Test
        @DisplayName("Empty first row matrix should return empty string")
        void shouldReturnEmptyStringForEmptyFirstRow() {
            assertEquals("", traversal.traverseSpiral(new int[][]{{}}));
        }

        /**
         * Verifies that a matrix with rows of varying lengths is identified as invalid.
         *
         * This test case ensures that the `isValidMatrix` method of the `ProcessMatrices` class
         * correctly identifies matrices that are not rectangular (i.e., matrices where not all rows
         * have the same number of columns) and returns `false` for such inputs.
         *
         * Assertions:
         * - Asserts that the method returns `false` when provided with a matrix containing
         *   rows of different lengths.
         */
        @Test
        @DisplayName("Matrix with unmatched rows should be invalid")
        void shouldReturnFalseForUnmatchedRows() {
            assertFalse(processMatrices.isValidMatrix(UNMATCHED_ROWS_MATRIX));
        }

        /**
         * Tests the spiral traversal functionality for a single-element matrix.
         *
         * This test verifies that the `traverseSpiral` method correctly handles the edge case
         * of a matrix containing only one element by ensuring the single element is returned
         * as the traversal result.
         *
         * Assertions:
         * - Validates that the traversal of a single-element matrix returns the expected string
         *   representation of the element.
         */
        @Test
        @DisplayName("Single element matrix should return the element")
        void shouldReturnElementForSingleElementMatrix() {
            assertEquals("9", traversal.traverseSpiral(SINGLE_ELEMENT_MATRIX));
        }
    }

    /**
     * Unit tests for validating the traversal behavior of linear matrices (1-dimensional matrices)
     * using the spiral order traversal feature.
     *
     * Contains specific test cases to ensure correct spiral traversal for both horizontal (1xN)
     * and vertical (Nx1) matrices.
     */
    @Nested
    @DisplayName("Linear Matrices")
    class LinearMatricesTests {
        /**
         * Ensures that a 1x4 matrix is traversed correctly in spiral order.
         *
         * This test validates the horizontal traversal behavior of a row matrix
         * using the `traverseSpiral` method from the `MatrixSpiralTraversal` class.
         *
         * Test case:
         * - Input: MATRIX_1X4, a 1x4 matrix containing sequential integer values [1, 2, 3, 4].
         * - Expected Output: A comma-separated string representation of the matrix elements
         *   traversed in spiral order, i.e., "1, 2, 3, 4".
         *
         * Assertion:
         * - Verifies that the output of the `traverseSpiral` method matches the expected result.
         */
        @Test
        @DisplayName("1x4 matrix should traverse horizontally")
        void shouldTraverseHorizontally() {
            assertEquals("1, 2, 3, 4", traversal.traverseSpiral(MATRIX_1X4));
        }

        /**
         * Ensures that a 4x1 matrix is traversed correctly in spiral order.
         *
         * This test validates the vertical traversal behavior of a column matrix
         * using the `traverseSpiral` method from the `MatrixSpiralTraversal` class.
         *
         * Test case:
         * - Input: MATRIX_4X1, a 4x1 matrix containing sequential integer values [1, 2, 3, 4].
         * - Expected Output: A comma-separated string representation of the matrix elements
         *   traversed in spiral order, i.e., "1, 2, 3, 4".
         *
         * Assertion:
         * - Verifies that the output of the `traverseSpiral` method matches the expected result.
         */
        @Test
        @DisplayName("4x1 matrix should traverse vertically")
        void shouldTraverseVertically() {
            assertEquals("1, 2, 3, 4", traversal.traverseSpiral(MATRIX_4X1));
        }
    }

    @Nested
    @DisplayName("Square Matrices")
    class SquareMatricesTests {
        /**
         * Tests the spiral traversal of a predefined 2x2 matrix.
         *
         * This test ensures the correctness of the traversal logic for a square matrix of size 2x2.
         * The matrix is expected to be traversed in a spiral order, starting from the top-left corner
         * and proceeding clockwise towards the center.
         *
         * Assertions:
         * - Validates that the spiral traversal of the predefined 2x2 matrix ({1, 2}, {3, 4})
         *   produces the expected output string of elements in spiral order: "1, 2, 4, 3".
         * - Ensures that the implementation of spiral traversal handles small square matrices correctly.
         */
        @Test
        @DisplayName("2x2 matrix should traverse in spiral order")
        void shouldTraverse2x2Matrix() {
            assertEquals("1, 2, 4, 3", traversal.traverseSpiral(MATRIX_2X2));
        }

        /**
         * Tests the spiral traversal of a predefined 3x3 matrix.
         *
         * This test ensures correctness of the {@link MatrixSpiralTraversal#traverseSpiral(int[][])} method when
         * applied to a square matrix of size 3x3. The matrix is expected to be traversed in a spiral order,
         * starting from the top-left element and moving towards the center.
         *
         * The test performs the following assertions:
         * - Validates that the spiral traversal of the predefined 3x3 matrix
         *   ({1, 2, 3}, {4, 5, 6}, {7, 8, 9}) matches the expected result.
         * - Ensures the correctness of the implementation for standard, valid matrix inputs.
         *
         * Assertions:
         * - Confirms that the returned traversal result matches the expected string
         *   of elements in spiral order.
         */
        @Test
        @DisplayName("3x3 matrix should traverse in spiral order")
        void shouldTraverse3x3Matrix() {
            assertEquals("1, 2, 3, 6, 9, 8, 7, 4, 5", traversal.traverseSpiral(MATRIX_3X3));
        }
    }

    /**
     * Unit tests for verifying the spiral traversal behavior of rectangular matrices.
     *
     * This nested test class evaluates the functionality of the matrix traversal logic,
     * particularly ensuring that rectangular matrices of various dimensions are traversed
     * correctly in spiral order.
     *
     * It covers scenarios for both wider (more columns than rows) and taller (more rows than columns) matrices.
     */
    @Nested
    @DisplayName("Rectangular Matrices")
    class RectangularMatricesTests {
        /**
         * Verifies that a 3x4 matrix is traversed correctly in spiral order.
         *
         * This unit test ensures that the traverseSpiral method correctly processes a
         * matrix with 3 rows and 4 columns and returns the expected result as a
         * comma-separated string. The test uses a predefined 3x4 matrix as input and
         * validates the output against the expected spiral traversal sequence.
         *
         * Assertions:
         * - Compares the actual output of the traverseSpiral method with the expected
         *   output to verify correctness.
         *
         * Preconditions:
         * - The input matrix is a non-ragged 3x4 integer matrix.
         * - The traverseSpiral method must be implemented correctly to handle matrices
         *   of this size and structure.
         */
        @Test
        @DisplayName("3x4 matrix should traverse in spiral order")
        void shouldTraverse3x4Matrix() {
            assertEquals("1, 2, 3, 4, 8, 12, 11, 10, 9, 5, 6, 7",
                    traversal.traverseSpiral(MATRIX_3X4));
        }

        /**
         * Verifies that a 4x3 matrix is traversed correctly in spiral order.
         *
         * This test ensures that the `traverseSpiral` method accurately processes a
         * rectangular matrix with 4 rows and 3 columns and produces the expected result
         * as a comma-separated string.
         *
         * Assertions:
         * - Validates that the output of the `traverseSpiral` method matches the anticipated
         *   spiral traversal sequence of the input matrix.
         *
         * Preconditions:
         * - The input matrix is a non-ragged 4x3 matrix with integer elements.
         * - The `traverseSpiral` method must handle the traversal logic for rectangular matrices
         *   of this dimension.
         */
        @Test
        @DisplayName("4x3 matrix should traverse in spiral order")
        void shouldTraverse4x3Matrix() {
            assertEquals("1, 2, 3, 6, 9, 12, 11, 10, 7, 4, 5, 8",
                    traversal.traverseSpiral(MATRIX_4X3));
        }
    }
}