package com.epicgames;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ProcessMatricesTest {

    /**
     * Tests the validity of a properly structured matrix using the isValidMatrix method
     * from the ProcessMatrices class.
     *
     * This test verifies that the method correctly identifies a valid 2D array
     * with all rows of equal length and without null elements as valid.
     *
     * Assertions:
     * - Ensures that the method returns true for a valid matrix.
     */

    @Test
    void testValidMatrix() {
        ProcessMatrices processMatrices = new ProcessMatrices();

        int[][] matrix = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };

        assertTrue(processMatrices.isValidMatrix(matrix), "A valid matrix should return true.");
    }

    /**
     * Tests the behavior of the isValidMatrix method when a null matrix is provided.
     *
     * This test ensures that the method correctly identifies a null input as invalid.
     *
     * Assertions:
     * - Verifies that the method returns false for a null matrix.
     */
    @Test
    void testNullMatrix() {
        ProcessMatrices processMatrices = new ProcessMatrices();

        int[][] matrix = null;

        assertFalse(processMatrices.isValidMatrix(matrix), "A null matrix should return false.");
    }

    @Test
    void testEmptyMatrix() {
        ProcessMatrices processMatrices = new ProcessMatrices();

        int[][] matrix = new int[0][0];

        assertFalse(processMatrices.isValidMatrix(matrix), "An empty matrix should return false.");
    }

    @Test
    void testMatrixWithNullRow() {
        ProcessMatrices processMatrices = new ProcessMatrices();

        int[][] matrix = {
                {1, 2, 3},
                null,
                {7, 8, 9}
        };

        assertFalse(processMatrices.isValidMatrix(matrix), "A matrix with a null row should return false.");
    }

    /**
     * Tests the behavior of the `isValidMatrix` method in the `ProcessMatrices` class
     * when provided with a matrix that contains uneven rows.
     *
     * This test ensures that the method correctly identifies a matrix with rows of varying lengths
     * as invalid. A valid matrix should have all rows of equal length.
     *
     * Assertions:
     * - Verifies that the method returns `false` for a matrix with uneven rows.
     */
    @Test
    void testMatrixWithUnevenRows() {
        ProcessMatrices processMatrices = new ProcessMatrices();

        int[][] matrix = {
                {1, 2, 3},
                {4, 5},
                {7, 8, 9}
        };

        assertFalse(processMatrices.isValidMatrix(matrix), "A matrix with uneven rows should return false.");
    }

    /**
     * Tests the behavior of the `isValidMatrix` method in the `ProcessMatrices` class
     * when provided with a matrix that exceeds the maximum allowed size.
     *
     * This test ensures that the method correctly identifies matrices with a row count
     * greater than the defined `MAX_MATRIX_SIZE` as invalid. The limit is enforced by
     * the `isValidMatrix` implementation.
     *
     * Assertions:
     * - Verifies that the `isValidMatrix` method returns `false` for a matrix
     *   exceeding the allowed size.
     */
    @Test
    void testMatrixExceedingMaxSize() {
        ProcessMatrices processMatrices = new ProcessMatrices();

        int[][] matrix = new int[1001][3]; // Exceeds the MAX_MATRIX_SIZE of 1000 rows.

        assertFalse(processMatrices.isValidMatrix(matrix), "A matrix exceeding the maximum size should return false.");
    }
}