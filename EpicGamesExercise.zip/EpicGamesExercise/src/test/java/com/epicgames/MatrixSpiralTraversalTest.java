package com.epicgames;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Test class for MatrixSpiralTraversal functionality.
 * Tests various matrix configurations including standard, single row/column, and empty matrices.
 */
class MatrixSpiralTraversalTest {

    /**
     * Standard 3x3 test matrix
     */
    private static final int[][] STANDARD_MATRIX = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
    };

    /**
     * Single row test matrix
     */
    private static final int[][] SINGLE_ROW_MATRIX = {
            {1, 2, 3, 4}
    };

    /**
     * Single column test matrix
     */
    private static final int[][] SINGLE_COLUMN_MATRIX = {
            {1},
            {2},
            {3},
            {4}
    };

    /**
     * Empty test matrix
     */
    private static final int[][] EMPTY_MATRIX = {};

    private final MatrixSpiralTraversal traversal = new MatrixSpiralTraversal();

    @Test
    void shouldTraverseStandardMatrixInSpiralOrder() {
        String expected = "1, 2, 3, 6, 9, 8, 7, 4, 5";
        assertEquals(expected, traversal.traverseSpiral(STANDARD_MATRIX));
    }

    @Test
    void shouldTraverseSingleRowMatrixFromLeftToRight() {
        String expected = "1, 2, 3, 4";
        assertEquals(expected, traversal.traverseSpiral(SINGLE_ROW_MATRIX));
    }

    @Test
    void shouldTraverseSingleColumnMatrixFromTopToBottom() {
        String expected = "1, 2, 3, 4";
        assertEquals(expected, traversal.traverseSpiral(SINGLE_COLUMN_MATRIX));
    }

    @Test
    void shouldReturnEmptyStringForEmptyMatrix() {
        String expected = "";
        assertEquals(expected, traversal.traverseSpiral(EMPTY_MATRIX));
    }
}