package com.epicgames.backendapi.controller;

import com.epicgames.backendapi.dto.PlayingGameModeDto;
import com.epicgames.backendapi.dto.PopularGameModeDto;
import com.epicgames.backendapi.service.GameModeService;
import com.epicgames.backendapi.service.PopularityService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GameModeControllerTest {

    private static final String COUNTRY_CODE_US = "US";
    private static final String COUNTRY_CODE_JP = "JP";
    private static final String MODE_NAME_BATTLE_ROYALE = "Battle Royale";
    private static final String GAME_NAME_EPIC = "Epic Game";
    private static final long POPULARITY_500 = 500L;
    private static final String PLAY_MODE_SOME = "SomeModeName";
    private static final String USER_ID_EXAMPLE = "4ef7808f-3d0e-42b2-9bff-aa441fd6f033";
    private static final String GAME_ID_EXAMPLE = "a21bd5f4-814e-46f3-9b0e-caba828878c4";

    @Mock
    private PopularityService popularityServiceMock;
    @Mock
    private GameModeService gameModeServiceMock;
    @InjectMocks
    private GameModeController gameModeController;
    @Mock
    private Executor gameModeExecutorMock;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        doAnswer(invocation -> {
            ((Runnable) invocation.getArgument(0)).run();
            return null;
        }).when(gameModeExecutorMock).execute(any(Runnable.class));
        gameModeController = new GameModeController(gameModeServiceMock, popularityServiceMock, gameModeExecutorMock);
    }

    @Test
    void shouldReturnPopularModes() {
        UUID gameId = UUID.randomUUID();
        List<PopularGameModeDto> expectedModes = Collections.singletonList(
                buildPopularGameModeDto(COUNTRY_CODE_US,gameId,GAME_NAME_EPIC,MODE_NAME_BATTLE_ROYALE, POPULARITY_500)
        );
        when(popularityServiceMock.getPopularGameModesByRegionAndGame(COUNTRY_CODE_US, gameId))
                .thenReturn(expectedModes);

        List<PopularGameModeDto> actualModes = popularityServiceMock.getPopularGameModesByRegionAndGame(COUNTRY_CODE_US, gameId);

        assertNotNull(actualModes);
        assertFalse(actualModes.isEmpty());
        assertEquals(expectedModes, actualModes);
    }

    @Test
    void shouldReturnEmptyListWhenNoPopularModes() {
        UUID gameId = UUID.randomUUID();
        when(popularityServiceMock.getPopularGameModesByRegionAndGame(COUNTRY_CODE_JP, gameId))
                .thenReturn(Collections.emptyList());

        List<PopularGameModeDto> actualModes = popularityServiceMock.getPopularGameModesByRegionAndGame(COUNTRY_CODE_JP, gameId);

        assertNotNull(actualModes);
        assertTrue(actualModes.isEmpty());
    }

    @Test
    void shouldReturnCurrentPlayingGameModeAndRegionForUser() {
        UUID userId = UUID.fromString(USER_ID_EXAMPLE);
        UUID gameId = UUID.fromString(GAME_ID_EXAMPLE);
        PlayingGameModeDto expectedDto = new PlayingGameModeDto(PLAY_MODE_SOME, COUNTRY_CODE_US);

        when(gameModeServiceMock.getRegionAndGameMode(userId, gameId))
                .thenReturn(expectedDto);

        CompletableFuture<ResponseEntity<PlayingGameModeDto>> responseFuture =
                gameModeController.getGameModeAndRegionByUserAndGame(userId, gameId);

        try {
            ResponseEntity<PlayingGameModeDto> response = responseFuture.get(5, TimeUnit.SECONDS);
            assertEquals(expectedDto, response.getBody());
        } catch (Exception e) {
            fail("Test failed due to: " + e.getMessage());
        }
    }

    private PopularGameModeDto buildPopularGameModeDto(String countryCode,UUID gameId, String modeName, String gameName, long popularity) {
        return new PopularGameModeDto(
                countryCode,
                gameId.toString(),
                gameName,
                UUID.randomUUID().toString(),
                modeName,
                popularity
        );
    }
}