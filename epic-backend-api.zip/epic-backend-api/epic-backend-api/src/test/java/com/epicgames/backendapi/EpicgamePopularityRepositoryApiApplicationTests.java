package com.epicgames.backendapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpicgamePopularityRepositoryApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
