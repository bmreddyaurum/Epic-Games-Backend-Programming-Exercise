package com.epicgames.backendapi.service;

import com.epicgames.backendapi.dto.PopularGameModeDto;
import com.epicgames.backendapi.model.Game;
import com.epicgames.backendapi.repository.PopularityRepository;
import com.epicgames.backendapi.repository.GameModeRepository;
import com.epicgames.backendapi.repository.GameRepository;
import com.epicgames.backendapi.repository.PopularityCountRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PopularityRepositoryServiceTest {

    private PopularityService popularityService;
    private GameModeRepository gameModeRepository;
    private GameRepository gameRepository;
    private PopularityCountRepository popularityCountRepository;
    private PopularityRepository popularityRepository;
    private StringRedisTemplate redisTemplate;

    @BeforeEach
    void setUp() {
        gameModeRepository = mock(GameModeRepository.class);
        gameRepository = mock(GameRepository.class);
        popularityCountRepository = mock(PopularityCountRepository.class);
        popularityRepository = mock(PopularityRepository.class);
        redisTemplate = mock(StringRedisTemplate.class);
        popularityService = new PopularityService(
                gameModeRepository, gameRepository, popularityCountRepository, redisTemplate, popularityRepository);
    }

    @Test
    @DisplayName("Should increment popularityRepository for provided country, mode and game IDs")
    void shouldIncrementPopularity() {
        // Arrange
        String country = "US";
        UUID modeId = UUID.randomUUID();
        UUID gameId = UUID.randomUUID();
        String expectedKey = String.format("popularityRepository:%s:%s:%s", country, modeId, gameId);

        ValueOperations<String, String> ops = mock(ValueOperations.class);
        when(redisTemplate.opsForValue()).thenReturn(ops);

        // Act
        popularityService.incrementPopularity(country, modeId, gameId);

        // Assert
        verify(redisTemplate.opsForValue(), times(1))
                .increment(expectedKey);
    }

    @Test
    @DisplayName("Should return popular game modes by region and game")
    void shouldReturnPopularGameModesByRegionAndGame() {
        // Arrange
        String country = "US";
        UUID gameId = UUID.randomUUID();

        // Simulate Redis does not provide data (fallback)
        when(redisTemplate.keys(anyString())).thenReturn(Collections.emptySet());

        // Mock DB fallback
        Game game = mock(Game.class);
        when(gameRepository.findById(gameId)).thenReturn(java.util.Optional.of(game));
              // Act
        List<PopularGameModeDto> result = popularityService.getPopularGameModesByRegionAndGame(country, gameId);

        // Assert
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}