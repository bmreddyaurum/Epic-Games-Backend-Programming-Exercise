package com.epicgames.backendapi.service;

import com.epicgames.backendapi.dto.PlayingGameModeDto;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GameModeServiceTest {
    private static final String REGION_US = "US";

    @Test
    @DisplayName("Should return current playing game mode and region for user")
    void shouldReturnCurrentPlayingGameModeAndRegionForUser() {
        // Arrange
        UUID userId = UUID.randomUUID();
        UUID gameId = UUID.randomUUID();
        PlayingGameModeDto expectedDto = new PlayingGameModeDto("SomeModeName", REGION_US);
        GameModeService gameModeServiceMock = mock(GameModeService.class);
        when(gameModeServiceMock.getRegionAndGameMode(userId, gameId)).thenReturn(expectedDto);

        // Act
        PlayingGameModeDto result = gameModeServiceMock.getRegionAndGameMode(userId, gameId);

        // Assert
        assertEquals(expectedDto, result);
    }
}