package com.epicgames.backendapi.service;

import com.epicgames.backendapi.model.PopularityCount;
import com.epicgames.backendapi.repository.PopularityCountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Tuple;

import java.util.List;
import java.util.UUID;

/**
 * Service class responsible for rebuilding the popularity count data.
 *
 * The PopularityRebuildBatchService aggregates play data from a database table
 * and updates the corresponding cached data in Redis and SQL storage. This service
 * is intended to be run as a batch job or scheduled task to ensure the popularity
 * counts are up-to-date based on the plays recorded in the system.
 *
 * Responsibilities:
 * - Aggregates play data by country, game mode, and game.
 * - Saves the aggregated popularity counts into the SQL database.
 * - Updates in-memory Redis data with the recalculated popularity counts.
 *
 * Methods:
 * - rebuildFromPlays: Aggregates play data and repopulates Redis and SQL data.
 * - scheduledRebuild: Periodically triggers the data rebuild process via a cron job.
 *
 * Annotations:
 * - @Service: Marks this class as a Spring service component.
 * - @RequiredArgsConstructor: Automatically generates a constructor for the required fields.
 * - @Transactional: Manages transactional boundaries for database operations.
 * - @Scheduled: Schedules the rebuild task using a cron expression.
 *
 * This service depends on:
 * - EntityManager: Used for querying aggregated play data from the database.
 * - StringRedisTemplate: Used for interacting with Redis to update in-memory popularity data.
 * - PopularityCountRepository: A data access object for the PopularityCount entity, used for persisting data.
 */
@Service
@RequiredArgsConstructor
public class PopularityRebuildBatchService {
    private static final String REDIS_POPULARITY_KEY_FORMAT = "popularityRepository:%s:%s:%s";
    private static final String REDIS_POPULARITY_KEY_PATTERN = "popularityRepository:%s:*:%s";

    private final EntityManager entityManager;
    private final StringRedisTemplate redisTemplate;
    private final PopularityCountRepository popularityCountRepository;

    /**
     * Aggregates play data from the Plays table and repopulates both
     * the popularity_counts SQL table and in-memory Redis keys.
     * Meant to be called as a one-off or admin operation.
     */
    @Transactional
    public void rebuildFromPlays() {
        List<Tuple> playAggregates = entityManager.createQuery(
                        "SELECT p.countryCode as country, " +
                                "p.gameModeId as gameMode, " +
                                "p.gameId as game, " +
                                "COUNT(p.id) as playCount " +
                                "FROM Plays p " +
                                "GROUP BY p.countryCode, p.gameModeId, p.gameId order by playCount desc", Tuple.class)
                .getResultList();

        // Do NOT delete all; let save() perform inserts or updates (upsert behavior)

        for (Tuple aggregate : playAggregates) {
            String country = aggregate.get("country", String.class);
            UUID modeId = aggregate.get("gameMode", UUID.class);
            UUID gameId = aggregate.get("game", UUID.class);
            Long count = aggregate.get("playCount", Long.class);

            savePopularityCount(country, modeId, gameId, count);
            updateRedisPopularityCount(country, modeId, gameId, count);
        }
    }

    private void savePopularityCount(String country, UUID modeId, UUID gameId, Long count) {
        PopularityCount entity = new PopularityCount();
        entity.setCountryCode(country);
        entity.setGameModeId(modeId);
        entity.setGameId(gameId);
        entity.setCount(count);
        popularityCountRepository.save(entity);
    }

    private void updateRedisPopularityCount(String country, UUID modeId, UUID gameId, Long count) {
        String redisKey = String.format(REDIS_POPULARITY_KEY_FORMAT, country, modeId, gameId);
        redisTemplate.opsForValue().set(redisKey, count.toString());
    }

    @Scheduled(cron = "1 * * * * *")
    public void scheduledRebuild() {
        rebuildFromPlays();
    }

}