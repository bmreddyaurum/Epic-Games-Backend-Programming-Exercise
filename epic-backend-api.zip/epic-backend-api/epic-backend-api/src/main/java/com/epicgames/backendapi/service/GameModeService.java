package com.epicgames.backendapi.service;

import com.epicgames.backendapi.dto.PlayingGameModeDto;

import com.epicgames.backendapi.model.Users;
import com.epicgames.backendapi.repository.GameModeRepository;
import com.epicgames.backendapi.repository.GameRepository;
import com.epicgames.backendapi.repository.PopularityCountRepository;
import com.epicgames.backendapi.repository.UserRepository;
import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Service class for handling game mode-related business logic.
 * Provides methods for retrieving and manipulating game modes,
 * including filtering by game, popularity, and region.
 */
@Service
@RequiredArgsConstructor
public class GameModeService {

    private static final String UNKNOWN_GAME_NAME = "Unknown";

    private final GameModeRepository gameModeRepository;
    private final PopularityCountRepository popularityCountRepository;
    private final GameRepository gameRepository;
    private final UserRepository userRepository;



    /**
     * Gets available mode names for a user's country and a specific game.
     */
    public PlayingGameModeDto getRegionAndGameMode(UUID userId, UUID gameId) {
        Users user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        String countryCode = user.getCountryCode();

        return gameModeRepository.findCurrentPlayingGameByUserAndGameAndCountry(userId,gameId, countryCode)
                .orElse(null);

    }

}