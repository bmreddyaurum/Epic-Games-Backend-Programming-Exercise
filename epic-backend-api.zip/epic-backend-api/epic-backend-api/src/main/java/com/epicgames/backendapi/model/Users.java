package com.epicgames.backendapi.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.UUID;

/**
 * Represents a user entity within the system.
 *
 * The Users entity is used to store and manage information about users
 * of the system, including their unique identifier, username, and
 * associated country code. This data is crucial for user authentication,
 * localization, and other user-related functionalities.
 *
 * This class is mapped to the "users" table in the database and employs
 * JPA annotations for persistence. Lombok annotations are used to
 * reduce boilerplate code such as getters, setters, equals, and hashcode.
 *
 * Attributes:
 * - id: A unique identifier for the user, represented as a UUID.
 * - username: The username of the user, which must be unique within the system.
 * - countryCode: The country of the user, represented as an ISO 3166-1 alpha-2 code.
 */
@Entity
@Data
public class Users {
    @Id
    private UUID id;

    @Column(nullable = false, unique = true, length = 64)
    private String username;

    @Column(name = "country_code", length = 2)
    private String countryCode;
}