package com.epicgames.backendapi.repository;

import com.epicgames.backendapi.model.PopularityCount;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface PopularityCountRepository extends JpaRepository<PopularityCount, PopularityCount.PopularityCountId> {


    List<PopularityCount> findByCountryCodeAndGameIdOrderByCountDesc(String countryCode, PopularityCount.PopularityCountId rediskey);
}