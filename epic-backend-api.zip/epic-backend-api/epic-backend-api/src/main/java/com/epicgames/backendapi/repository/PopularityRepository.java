package com.epicgames.backendapi.repository;

import com.epicgames.backendapi.dto.PopularGameModeDto;
import com.epicgames.backendapi.model.Plays;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

/**
 * Repository for popularity queries on the Plays table.
 */
public interface PopularityRepository extends JpaRepository<Plays, UUID> {

    /**
     * Retrieves a list of popular game modes for a specific game in a given country,
     * ordered by their popularity in descending order. PopularityRepository is calculated based
     * on the number of times a game mode has been chosen in the provided country by players.
     *
     * @param countryCode the ISO 3166-1 alpha-2 code representing the country for which
     *                    popular game modes are to be retrieved.
     * @param gameId the unique identifier of the game for which the query is performed.
     * @return a list of {@code PopularGameModeDto} objects containing details about the
     *         popular game modes in the specified country for the given game, sorted
     *         by their popularity in descending order.
     */
    @Query(value = """
           SELECT
                  p.country_code as countryCode,
                  CAST(p.game_id AS VARCHAR(36)) as gameId,
                  g.name as gameName,
                  CAST(p.game_mode_id AS VARCHAR(36)) as gameModeId,
                  gm.mode_name as modeName,
                  COUNT(p.game_mode_id) as popularity
            FROM plays p
                 join game_modes gm on p.game_mode_id = gm.id
                 join games g on p.game_id = g.id
            WHERE p.country_code = :countryCode AND p.game_id = CAST(:gameId AS UUID)
            GROUP BY p.country_code, p.game_id, p.game_mode_id, g.name, gm.mode_name
            ORDER BY COUNT(p.game_mode_id) DESC 
        """, nativeQuery = true)
    List<PopularGameModeDto> findByCountryCodeAndGameIdOrderByCountDesc
    (
            @Param("countryCode") String countryCode,
            @Param("gameId") UUID gameId
    );


}