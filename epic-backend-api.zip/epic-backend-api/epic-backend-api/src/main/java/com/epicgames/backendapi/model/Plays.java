package com.epicgames.backendapi.model;

import jakarta.persistence.*;
import lombok.*;
import java.util.UUID;
import java.time.LocalDateTime;

/**
 * Represents a play entry within the system.
 *
 * The Plays entity tracks individual gameplay sessions, recording information such as
 * the user who played, the game and game mode they played in, the country where the play
 * occurred, and the timestamp of the session.
 *
 * This class is mapped to the "plays" table in the database and utilizes JPA and Lombok
 * annotations for persistence and boilerplate code generation.
 *
 * Attributes:
 * - id: A unique identifier for each play record.
 * - userId: The unique identifier for the user associated with this play session.
 * - gameId: The unique identifier for the game associated with this play session.
 * - gameModeId: The unique identifier for the game mode associated with this play session.
 * - countryCode: The country in which the play session occurred, represented as an ISO 3166-1 alpha-2 code.
 * - timestamp: The exact date and time when the play session occurred.
 */
@Entity
@Table(name = "plays")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Plays {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "user_id", nullable = false)
    private UUID userId;

    @Column(name = "game_id", nullable = false)
    private UUID gameId;

    @Column(name = "game_mode_id", nullable = false)
    private UUID gameModeId;

    @Column(name = "country_code", length = 10, nullable = false)
    private String countryCode;

    @Column(name = "timestamp", nullable = false)
    private LocalDateTime timestamp;
}