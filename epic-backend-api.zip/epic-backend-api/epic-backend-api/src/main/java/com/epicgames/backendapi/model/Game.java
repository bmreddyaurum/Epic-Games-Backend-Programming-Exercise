package com.epicgames.backendapi.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.UUID;

/**
 * Represents a game entity within the system.
 *
 * The Game entity is used to store and manage information about games,
 * including their unique identifier, name, associated country, description,
 * and the maximum number of players allowed.
 *
 * This class is mapped to the "games" table in the database and is annotated
 * with JPA and Lombok annotations for persistence and boilerplate code generation.
 */
@Entity
@Table(name = "games")
@Data
public class Game {

    @Id
    private UUID id;

    @Column(nullable = false, length = 50)
    private String name;

    @Column(name = "country_code")
    private String countryCode;


    @Column(length = 128)
    private String description;

    @Column(name = "max_players")
    private Integer maxPlayers;
}