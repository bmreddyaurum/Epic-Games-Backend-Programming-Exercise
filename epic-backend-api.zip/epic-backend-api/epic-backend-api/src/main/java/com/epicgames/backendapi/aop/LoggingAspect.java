package com.epicgames.backendapi.aop;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * Aspect for logging execution of service layer methods.
 *
 * This aspect intercepts all method executions within the service package
 * and logs the method details, including method name, input arguments,
 * result, and any exceptions that may occur during execution.
 */
@Aspect
@Component
@Slf4j
public class LoggingAspect {


    @Pointcut("within(com.epicgames.backendapi.service..*)")
    public void serviceMethods() {}

    @Pointcut("@within(org.springframework.web.bind.annotation.RestController)")
    public void restControllerMethods() {}

    @Around("restControllerMethods()")
    public Object profileController(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        try {
            return joinPoint.proceed();
        } finally {
            long duration = System.currentTimeMillis() - start;
            log.info("REST [{}] executed in {} ms", joinPoint.getSignature(), duration);
        }
    }


    @Around("serviceMethods()")
    public Object logMethod(ProceedingJoinPoint joinPoint) throws Throwable {
        log.info("Entering: {} with arguments = {}", joinPoint.getSignature(), Arrays.toString(joinPoint.getArgs()));
        try {
            Object result = joinPoint.proceed();
            log.info("Exiting: {} with result = {}", joinPoint.getSignature(), result);
            return result;
        } catch (Throwable ex) {
            log.error("Exception in: {} with cause = {}", joinPoint.getSignature(), ex.getMessage());
            throw ex;
        }
    }

    @Around("serviceMethods()")
    public Object profileExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        try {
            return joinPoint.proceed();
        } finally {
            long duration = System.currentTimeMillis() - start;
            log.info("Execution time of {}: {} ms", joinPoint.getSignature(), duration);
        }
    }
}