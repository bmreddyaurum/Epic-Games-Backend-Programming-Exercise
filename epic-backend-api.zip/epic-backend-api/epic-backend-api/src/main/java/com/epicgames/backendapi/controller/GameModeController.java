package com.epicgames.backendapi.controller;

import com.epicgames.backendapi.dto.PlayingGameModeDto;
import com.epicgames.backendapi.dto.PopularGameModeDto;
import com.epicgames.backendapi.exception.ResourceNotFoundException;
import com.epicgames.backendapi.service.GameModeService;
import com.epicgames.backendapi.service.PopularityService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Controller class for managing game mode-related APIs.
 * Handles endpoints for retrieving user-specific game modes and regional popularity of game modes.
 */
@Validated
@RestController
@RequestMapping(GameModeController.API_V1)
public class GameModeController {

    static final String API_V1 = "/api/v1";
    static final String REPORT_USER_REGION_MODE_PATH = "/playingmode/{userId}/{gameId}";
    static final String POPULARITY_PATH = "/popularity/gamemode/{countryCode}/{gameId}";

    private static final String USER_GAME_ERROR_MSG = "User: %s has no data for game: %s";
    private static final String COUNTRY_GAME_ERROR_MSG = "CountryCode: %s has no data for game: %s";

    private final GameModeService gameModeService;
    private final PopularityService popularityService;
    private final Executor gameModeExecutor;


    @Autowired
    public GameModeController(GameModeService gameModeService,
                              PopularityService popularityService,
                              Executor gameModeExecutor) {
        this.gameModeService = gameModeService;
        this.popularityService = popularityService;
        this.gameModeExecutor = gameModeExecutor;
    }


    /**
     * Retrieves the currently playing game mode and associated region for a given user and game.
     *
     * This method fetches the data asynchronously and returns the details of the
     * game mode being played by the specified user along with the associated region.
     * If no data is found, the method ensures a resource not found exception is handled.
     *
     * @param userId the unique identifier of the user; must not be null
     * @param gameId the unique identifier of the game; must not be null
     * @return a CompletableFuture containing a ResponseEntity with a
     *         PlayingGameModeDto object that includes the game mode and region information
     */
    @Operation(summary = REPORT_USER_REGION_MODE_PATH, description = """
            Retrieves the currently playing game mode and associated region for a given user and game.
             * @param userId the unique identifier of the user; must not be null
             * @param gameId the unique identifier of the game; must not be null
             * @return a CompletableFuture containing a ResponseEntity with a\s
             * PlayingGameModeDto object that includes the game mode and region information
            """)
    @GetMapping(REPORT_USER_REGION_MODE_PATH)
    public CompletableFuture<ResponseEntity<PlayingGameModeDto>> getGameModeAndRegionByUserAndGame(
            @PathVariable @NotNull(message = "User ID must not be null") UUID userId,
            @PathVariable @NotNull(message = "Game ID must not be null") UUID gameId) {
        return CompletableFuture.supplyAsync(() -> {
            PlayingGameModeDto dto = gameModeService.getRegionAndGameMode(userId, gameId);
            validateResourceExists(dto, String.format(USER_GAME_ERROR_MSG, userId, gameId));
            return ResponseEntity.ok(dto);
        }, gameModeExecutor); // Use the custom pool here!
    }


    /**
     * Retrieves a list of the most popular game modes for a specified country and game.
     *
     * This method fetches data based on the provided country code and game ID. It ensures
     * that the requested information exists and throws an exception if no associated
     * data is found.
     *
     * @param countryCode the two-letter uppercase country code (ISO 3166-1 alpha-2);
     *                    must not be blank, must be exactly 2 characters long, and
     *                    must consist of uppercase letters only
     * @param gameId      the unique identifier of the game; must not be null
     * @return a ResponseEntity containing a list of {@code PopularGameModeDto} objects
     *         representing the most popular game modes for the given country and game
     */
    @Operation(summary = POPULARITY_PATH, description = """
            Get a list of the most popular game modes for a country and game.
            @param countryCode the two-letter uppercase country code (ISO 3166-1 alpha-2); 
            must not be blank, must be exactly 2 characters long, and 
            must consist of uppercase letters only
            @param gameId      the unique identifier of the game; must not be null
            @return a ResponseEntity containing a list of {@code PopularGameModeDto} objects 
            representing the most popular game modes for the given country and game
            """)
    @GetMapping(POPULARITY_PATH)
    public ResponseEntity<List<PopularGameModeDto>> getPopularModesByRegionAndGame(
            @PathVariable
            @NotBlank(message = "Country code must not be blank")
            @Size(min = 2, max = 2, message = "Country code must be 2 characters")
            @Pattern(regexp = "^[A-Z]{2}$", message = "Country code must be 2 uppercase letters")
            String countryCode,
            @PathVariable @NotNull(message = "Game ID must not be null") UUID gameId
    ) {
        List<PopularGameModeDto> dto = popularityService.getPopularGameModesByRegionAndGame(countryCode, gameId);
        validateResourceExists(dto, String.format(COUNTRY_GAME_ERROR_MSG, countryCode, gameId));
        return ResponseEntity.ok(dto);
    }

    private void validateResourceExists(Object resource, String errorMessage) {
        if (resource == null
                || (resource instanceof List && ((List<?>) resource).isEmpty())) {
            throw new ResourceNotFoundException(errorMessage);
        }
    }
}