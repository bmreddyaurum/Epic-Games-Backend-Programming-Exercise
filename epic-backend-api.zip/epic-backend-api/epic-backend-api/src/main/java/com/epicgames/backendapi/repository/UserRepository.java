package com.epicgames.backendapi.repository;

import com.epicgames.backendapi.model.Users;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface UserRepository extends JpaRepository<Users, UUID> {
}