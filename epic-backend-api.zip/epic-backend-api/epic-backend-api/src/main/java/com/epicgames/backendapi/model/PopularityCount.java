package com.epicgames.backendapi.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import java.util.UUID;

/**
 * Represents a popularity count entity within the system.
 *
 * The PopularityCount entity is used to store and manage data related to the popularity
 * of specific games and game modes in different countries. This can help track trends
 * and preferences based on geographic regions. The class consists of composite keys
 * to uniquely identify entries based on a combination of country code, game mode,
 * and game id.
 *
 * This class is mapped to the "popularity_counts" table in the database using JPA
 * annotations and utilizes Lombok for boilerplate code generation.
 *
 * Attributes:
 * - countryCode: Represents the ISO 3166-1 alpha-2 code of the country.
 * - gameModeId: Represents the unique identifier for the game mode.
 * - gameId: Represents the unique identifier for the game.
 * - count: Represents the popularity count associated with the specific country,
 *   game mode, and game.
 *
 * Nested Class:
 * - PopularityCountId: A static nested class that serves as the composite ID for
 *   this entity. It includes the combination of countryCode, gameModeId, and gameId
 *   to uniquely identify any PopularityCount entity.
 */
@Data
@NoArgsConstructor
@Entity
@Table(name = "popularity_counts")
@IdClass(PopularityCount.PopularityCountId.class)
public class PopularityCount {

    @Id
    @Column(name = "country_code", length = 2)
    private String countryCode;

    @Id
    @Column(name = "game_mode_id", columnDefinition = "UUID")
    private UUID gameModeId;

    @Id
    @Column(name = "game_id", columnDefinition = "UUID")
    private UUID gameId;

    @Column(name = "count")
    private long count;

    /**
     * Represents the composite key for the PopularityCount entity.
     *
     * The PopularityCountId class defines a composite primary key consisting of the
     * following fields:
     * - countryCode: The ISO 3166-1 alpha-2 code of a country.
     * - gameModeId: A unique identifier representing a specific game mode.
     * - gameId: A unique identifier representing a specific game.
     *
     * This class is marked as Serializable to ensure its compatibility within the JPA
     * framework for entities that require composite keys.
     *
     * It serves as the identifier class for the PopularityCount entity and is used to
     * uniquely identify a record in the corresponding database table.
     *
     * The class leverages Lombok annotations to generate boilerplate code such as
     * getters, setters, equals, hashcode, and constructors.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PopularityCountId implements Serializable {
        private String countryCode;
        private UUID gameModeId;
        private UUID gameId;
    }
}