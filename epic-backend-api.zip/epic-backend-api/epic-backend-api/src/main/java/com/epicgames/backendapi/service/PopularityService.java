package com.epicgames.backendapi.service;

import com.epicgames.backendapi.dto.PopularGameModeDto;
import com.epicgames.backendapi.model.Game;
import com.epicgames.backendapi.model.GameMode;
import com.epicgames.backendapi.repository.GameModeRepository;
import com.epicgames.backendapi.repository.GameRepository;
import com.epicgames.backendapi.repository.PopularityRepository;
import com.epicgames.backendapi.repository.PopularityCountRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PopularityService {
    private static final Logger logger = LoggerFactory.getLogger(PopularityService.class);

    private static final String REDIS_POPULARITY_KEY_FORMAT = "popularityRepository:%s:%s:%s";
    private static final String REDIS_POPULARITY_KEY_PATTERN = "popularityRepository:%s:*:%s";

    private final GameModeRepository gameModeRepository;
    private final GameRepository gameRepository;
    private final PopularityCountRepository popularityCountRepository;
    private final StringRedisTemplate redisTemplate;
    private final PopularityRepository popularityRepository;

    /**
     * Retrieve the most popular game modes for a specific country and game.
     * Uses Redis when available, otherwise falls back to the database.
     */
    /**
     * Increments the popularityRepository counter for a specific game mode in a specific country.
     *
     * @param country the country code (e.g., "US")
     * @param modeId  the UUID of the game mode
     * @param gameId  the UUID of the game
     */
    public void incrementPopularity(String country, UUID modeId, UUID gameId) {
        String key = String.format(REDIS_POPULARITY_KEY_FORMAT, country, modeId, gameId);
        redisTemplate.opsForValue().increment(key);
        logger.debug("Incremented popularityRepository for key: {}", key);
    }

    public List<PopularGameModeDto> getPopularGameModesByRegionAndGame(String countryCode, UUID gameId) {
        String redisPattern = String.format(REDIS_POPULARITY_KEY_PATTERN, countryCode, gameId);
        long start = System.nanoTime();
        boolean fromRedis = true;




        Set<String> redisKeys = null;
        try {
            redisKeys = redisTemplate.keys(redisPattern);
            fromRedis = true;

        } catch (Exception ex) {
            // Log the exception and proceed to fallback
            System.err.println("[Redis Fallback] Redis unavailable, falling back to DB: " + ex.getMessage());
            redisKeys = null;
            fromRedis = false;

        }

        if (redisKeys != null && !redisKeys.isEmpty()) {
            fromRedis = true;

            // Fetch from Redis and build the DTO list
            List<PopularGameModeDto> result = redisKeys.stream()
                    .map(key -> {
                        String[] parts = key.split(":");
                        if (parts.length < 4) return null;
                        String modeIdStr = parts[2];
                        String gameIdStr = parts[3];
                        String modeId;
                        String gameIdParsed;
                        try {
                            modeId = modeIdStr;
                            gameIdParsed = gameIdStr;
                        } catch (Exception parseEx) {
                            return null; // skip invalid
                        }
                        Long count;
                        try {
                            String v = redisTemplate.opsForValue().get(key);
                            count = v == null ? 0L : Long.parseLong(v);
                        } catch (Exception anyEx) {
                            count = 0L;
                        }

                        Optional<GameMode> gm = gameModeRepository.findById(UUID.fromString(modeIdStr));
                        String modeName = gm.map(GameMode::getModeName).orElse("unknown");
                        String gameIdVal = gm.isPresent() ? gm.get().getGameId().toString() : gameIdParsed;
                        String gameName = gameRepository.findById(UUID.fromString(gameIdVal)).map(Game::getName).orElse("unknown");

                        return new PopularGameModeDto(countryCode, gameIdVal, gameName, modeId, modeName, count);
                    })
                    .filter(Objects::nonNull)
                    .sorted(Comparator.comparingLong(PopularGameModeDto::getPopularity).reversed())
                    .collect(Collectors.toList());
            if (!result.isEmpty()) {

                long durationMs = (System.nanoTime() - start) / 1_000_000;
                logger.info("Fetched popular game modes for [{}:{}] from {} in {} ms",
                        countryCode, gameId, fromRedis ? "Redis" : "Database", durationMs);
                return result;
            }
        }
        fromRedis = false;
        long durationMs = (System.nanoTime() - start) / 1_000_000;
        logger.info("Fetched popular game modes for [{}:{}] from {} in {} ms",
                countryCode, gameId, fromRedis ? "Redis" : "Database", durationMs);
        // Fallback: Fetch from DB if Redis fails or empty
        return popularityRepository.findByCountryCodeAndGameIdOrderByCountDesc(countryCode, gameId);
    }
}