package com.epicgames.backendapi.util;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class SQLDataGenerator {
    private static final String SQL_FILE_PATH = "./src/main/resources/data.sql";
    private static final String PLAY_TIMESTAMP_PATTERN = "2024-07-29 09:%02d:00";

    private static final String[] COUNTRY_CODES = {
            "US", "SG", "IN", "FR", "DE", "UK", "JP", "CN", "KR", "BR",
            "RU", "AU", "CA", "ZA", "SA", "AE", "MX", "ES", "IT", "TR"
    };
    private static final String[] COUNTRY_NAMES = {
            "United States", "Singapore", "India", "France", "Germany", "United Kingdom", "Japan", "China", "South Korea", "Brazil",
            "Russia", "Australia", "Canada", "South Africa", "Saudi Arabia", "UAE", "Mexico", "Spain", "Italy", "Turkey"
    };

    private static final Random RANDOM = new Random(12345); // deterministic for demo

    private static final Map<String, List<String>> countryToUserIds = new HashMap<>();
    private static final Map<String, String> modeIdToCountry = new HashMap<>();
    private static final Map<String, String> modeIdToGameId = new HashMap<>();
    private static final Map<String, Map<String, Integer>> countryModePlayCounts = new HashMap<>();

    public static void main(String[] args) throws IOException {
        StringBuilder sb = new StringBuilder();
        generateCountryInserts(sb);
        generateUserInserts(sb);
        generateGameInserts(sb);
        generateGameModeInserts(sb);
        int totalPlays = generatePlayInserts(sb);
        sb.append("\n-- Total Plays rows generated: ").append(totalPlays).append("\n");
        generatePopularityCountsInserts(sb);
        try (FileWriter writer = new FileWriter(SQL_FILE_PATH)) {
            writer.write(sb.toString());
        }
        System.out.println(sb);
        System.out.println("\n✅ SQL insert statements written to data.sql");
    }

    private static void generateCountryInserts(StringBuilder sb) {
        sb.append("INSERT INTO countries (code, name) VALUES\n");
        for (int i = 0; i < COUNTRY_CODES.length; i++) {
            sb.append(String.format("('%s', '%s')%s\n",
                    COUNTRY_CODES[i], COUNTRY_NAMES[i], (i < COUNTRY_CODES.length - 1 ? "," : ";")));
        }
        sb.append("\n");
    }

    private static void generateUserInserts(StringBuilder sb) {
        sb.append("INSERT INTO users (id, username, country_code) VALUES\n");
        for (int i = 1; i <= 10; i++) {
            String userId = uuidStr(i);
            String country = COUNTRY_CODES[(i - 1) % COUNTRY_CODES.length];
            countryToUserIds.computeIfAbsent(country, k -> new ArrayList<>()).add(userId);
            sb.append(String.format("('%s', 'user%d', '%s')%s\n", userId, i, country, (i < 10 ? "," : ";")));
        }
        sb.append("\n");
    }

    private static void generateGameInserts(StringBuilder sb) {
        sb.append("INSERT INTO games (id, name, description, country_code, max_players) VALUES\n");
        for (int i = 1; i <= 10; i++) {
            String gameId = uuidStr(i + 1000);
            String country = COUNTRY_CODES[(i - 1) % COUNTRY_CODES.length];
            int maxPlayers = ((i * 10) % 101) + 2;
            sb.append(String.format("('%s', 'Game%d', 'Description for Game%d', '%s', %d)%s\n",
                    gameId, i, i, country, maxPlayers, (i < 10 ? "," : ";")));
        }
        sb.append("\n");
    }

    private static void generateGameModeInserts(StringBuilder sb) {
        sb.append("INSERT INTO game_modes (id, game_id, mode_name, max_players, country_code, description) VALUES\n");
        int modeIndex = 1;
        for (int g = 1; g <= 10; g++) {
            String gameId = uuidStr(g + 1000);
            String country = COUNTRY_CODES[(g - 1) % COUNTRY_CODES.length];
            for (int m = 1; m <= 50; m++, modeIndex++) {
                String modeId = uuidStr(modeIndex + 10000);
                modeIdToCountry.put(modeId, country);
                modeIdToGameId.put(modeId, gameId);
                int maxPlayers = ((m * 2 + g) % 100) + 1;
                sb.append(String.format("('%s', '%s', 'Mode%d', %d, '%s', 'Mode%d for Game%d')%s\n",
                        modeId, gameId, m, maxPlayers, country, m, g, (modeIndex < 500 ? "," : ";")));
            }
        }
        sb.append("\n");
    }

    private static int generatePlayInserts(StringBuilder sb) {
        sb.append("INSERT INTO Plays (id, user_id, game_id, game_mode_id, country_code, timestamp) VALUES\n");
        int playSeq = 1;
        int totalPlays = 0;
        for (String country : COUNTRY_CODES) {
            List<String> modesForCountry = getModesForCountry(country);
            if (modesForCountry.isEmpty()) continue;
            for (String modeId : modesForCountry) {
                int playCount = 2 + RANDOM.nextInt(14);
                List<String> userIds = countryToUserIds.get(country);
                String gameId = modeIdToGameId.get(modeId);
                countryModePlayCounts
                        .computeIfAbsent(country, k -> new HashMap<>())
                        .put(modeId, playCount);
                for (int i = 0; i < playCount; i++, playSeq++) {
                    String userId = userIds.get(RANDOM.nextInt(userIds.size()));
                    String timestamp = String.format(PLAY_TIMESTAMP_PATTERN, playSeq % 60);
                    sb.append(String.format("('%s', '%s', '%s', '%s', '%s', '%s')%s\n",
                            uuidStr(playSeq + 20000), userId, gameId, modeId, country, timestamp, ","));
                    totalPlays++;
                }
            }
        }
        // Replace last comma with semicolon
        int lastComma = sb.lastIndexOf(",");
        if (lastComma >= 0) sb.replace(lastComma, lastComma + 1, ";");
        return totalPlays;
    }

    private static List<String> getModesForCountry(String country) {
        List<String> result = new ArrayList<>();
        for (Map.Entry<String, String> entry : modeIdToCountry.entrySet()) {
            if (entry.getValue().equals(country)) result.add(entry.getKey());
        }
        return result;
    }

    private static void generatePopularityCountsInserts(StringBuilder sb) {
        sb.append("INSERT INTO popularity_counts (country_code, game_mode_id, game_id, count) VALUES\n");
        List<String> popLines = new ArrayList<>();
        int popTotal = 0;
        for (Map.Entry<String, Map<String, Integer>> entry : countryModePlayCounts.entrySet()) {
            String country = entry.getKey();
            Map<String, Integer> modeCounts = entry.getValue();
            for (Map.Entry<String, Integer> modeEntry : modeCounts.entrySet()) {
                String modeId = modeEntry.getKey();
                String gameId = modeIdToGameId.get(modeId);
                int count = modeEntry.getValue();
                popLines.add(String.format("('%s', '%s', '%s', %d)", country, modeId, gameId, count));
                popTotal++;
            }
        }
        for (int i = 0; i < popLines.size(); i++) {
            sb.append(popLines.get(i)).append(i < popLines.size() - 1 ? ",\n" : ";\n");
        }
        sb.append("-- Total popularity_counts rows generated: ").append(popTotal).append("\n");
    }

    // Generates deterministic, valid UUID string (for demo)
    static String uuidStr(int n) {
        String left = String.format("%08x", n);
        String mid1 = String.format("%04x", n);
        String mid2 = String.format("%04x", n + 1);
        String mid3 = String.format("%04x", n + 2);
        String right = String.format("%012x", n);
        return left + "-" + mid1 + "-" + mid2 + "-" + mid3 + "-" + right;
    }
}