package com.epicgames.backendapi.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.UUID;

/**
 * Data Transfer Object representing a popular game mode in a specific region,
 * along with relevant metadata about the game and its popularity.
 *
 * This class is typically used to transfer data between the service layer and
 * the controller layer in the context of determining the most played or popular
 * game modes in a given country or globally across different games.
 *
 * Fields:
 * - `countryCode`: ISO 3166-1 alpha-2 code representing the country or region.
 * - `gameId`: Unique identifier for the game to which the game mode belongs.
 * - `gameName`: Name of the game associated with the game mode.
 * - `gameModeId`: Unique identifier of the game mode.
 * - `modeName`: Name of the game mode.
 * - `popularity`: PopularityRepository value, typically represented as a count of how many players chose this game mode or interacted with it.
 *
 * Instances of this class are often created from aggregated data, retrieved either
 * from a database or caching system (like Redis), and utilized in features such as
 * leaderboards or activity dashboards.
 */
@Data
@AllArgsConstructor
public class PopularGameModeDto {
    private String countryCode;
    private String gameId;
    private String gameName;
    private String gameModeId;
    private String modeName;
    private long popularity;
}