package com.epicgames.backendapi.repository;

import com.epicgames.backendapi.dto.PlayingGameModeDto;
import com.epicgames.backendapi.model.GameMode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

/**
 * Repository interface for managing `GameMode` entities and performing custom queries
 * related to game modes within the system.
 *
 * Extends the JpaRepository interface, providing built-in methods for CRUD operations
 * and custom query execution. This repository primarily interacts with the
 * `game_modes`, `plays`, `games` table in the database.
 *
 * Methods:
 * - Provides access to basic CRUD operations as part of JpaRepository.
 * - Contains custom query methods for retrieving game mode details by various parameters.
 *
 * Custom Queries:
 * - `findCurrentPlayingGameByUserAndGameAndCountry`: Retrieves the most recently played
 *   game mode for a specific user, game, and country, ordered by timestamp.
 *
 * Purpose:
 * This repository acts as a data access layer for working with the `GameMode` entity
 * and related data, allowing integration with database operations efficiently.
 */
public interface GameModeRepository extends JpaRepository<GameMode, UUID> {


    @Query(value = """
    SELECT gm.mode_name AS modeName, p.country_code AS countryCode
    FROM plays p
    JOIN game_modes gm ON p.game_mode_id = gm.id
    JOIN games g ON p.game_id = g.id
    WHERE p.user_id = :userId AND p.country_code = :countryCode AND p.game_id = :gameId
    ORDER BY p.timestamp DESC
    LIMIT 1
    """, nativeQuery = true)
        Optional<PlayingGameModeDto> findCurrentPlayingGameByUserAndGameAndCountry(
                @Param("userId") UUID userId,
                @Param("gameId") UUID gameId,
                @Param("countryCode") String countryCode
        );

}