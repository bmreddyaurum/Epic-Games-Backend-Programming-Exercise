package com.epicgames.backendapi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.*;

/**
 * Configuration class for initializing and setting up the Redis connection
 * and templates for interacting with Redis in the application.
 * This class contains beans that configure the Redis connection factory
 * and provides a Redis template for working with Redis data stores.
 */
@Configuration
public class RedisConfig {


    /**
     * Creates and configures a {@link LettuceConnectionFactory} for connecting to a Redis data store.
     *
     * @return a configured instance of {@link LettuceConnectionFactory} to manage Redis connections.
     */
    @Bean
    public LettuceConnectionFactory redisConnectionFactory() {
        return new LettuceConnectionFactory();
    }
    /**
     * Creates a {@link StringRedisTemplate} bean to interact with Redis using string-based keys and values.
     * This template provides high-level operations for working with Redis in a Spring application.
     *
     * @param connectionFactory the {@link LettuceConnectionFactory} used to establish the connection to the Redis data store
     * @return a configured {@link StringRedisTemplate} instance to perform Redis operations
     */
    @Bean
    public StringRedisTemplate stringRedisTemplate(LettuceConnectionFactory connectionFactory) {
        return new StringRedisTemplate(connectionFactory);
    }
}