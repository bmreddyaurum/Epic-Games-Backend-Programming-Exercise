package com.epicgames.backendapi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Configuration class for setting up asynchronous task execution.
 * This class is responsible for defining a thread pool executor
 * to handle asynchronous operations in the application, based on
 * a predefined core pool size.
 */
@Configuration
public class AsyncConfig {
    @Value("${custom.ThreadPool.corePoolSize}")
    private int corePoolSize;

    @Bean
    public Executor gameModeExecutor() {
        return Executors.newFixedThreadPool(corePoolSize);
    }
}