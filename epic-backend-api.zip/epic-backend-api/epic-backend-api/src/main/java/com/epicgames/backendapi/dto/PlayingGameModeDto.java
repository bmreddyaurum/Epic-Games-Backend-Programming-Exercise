package com.epicgames.backendapi.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object representing the current game mode being played by a user,
 * along with the associated country or region.
 *
 * This class contains minimal information required to represent the user's
 * current game session details, useful in features such as tracking the
 * most played game mode in a particular region.
 *
 * Fields:
 * - `modeName`: The name of the currently played game mode.
 * - `countryCode`: The ISO 3166-1 alpha-2 code representing the user's country or region.
 *
 * This DTO is typically used in the context of transferring data between the service
 * or repository layer and the controller layer in a REST API.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlayingGameModeDto {
    private String modeName;
    private String countryCode;
}