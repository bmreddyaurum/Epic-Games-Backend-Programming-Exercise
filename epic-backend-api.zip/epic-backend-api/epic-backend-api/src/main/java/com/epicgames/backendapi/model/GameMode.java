package com.epicgames.backendapi.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.UUID;

/**
 * Represents a game mode entity within the system.
 *
 * The GameMode entity stores information about specific modes within a game,
 * including its unique identifier, associated game, mode name, country code,
 * maximum players allowed, and a short description.
 *
 * This entity is mapped to the "game_modes" table in the database. It includes
 * constraints to ensure uniqueness for mode names within the scope of a single game.
 * The fields of this class define the attributes of a game mode and their respective
 * database mappings.
 *
 * This class utilizes annotations from JPA for persistence and Lombok for generating
 * boilerplate code such as getters, setters, equals, hashcode, and toString methods.
 */
@Entity
@Table(
    name = "game_modes",
    uniqueConstraints = {
        @UniqueConstraint(columnNames = {"game_id", "mode_name"})
    }
)
@Data
public class GameMode {

    @Id
    private UUID id;

    @Column(name = "game_id", nullable = false)
    private UUID gameId;

    @Column(name = "mode_name", nullable = false, length = 64)
    private String modeName;

    @Column(name = "country_code")
    private String countryCode;


    @Column(name = "max_players")
    private Integer maxPlayers;

    @Column(length = 128)
    private String description;
}