package com.epicgames.backendapi.service;

import com.epicgames.backendapi.model.PopularityCount;
import com.epicgames.backendapi.repository.PopularityCountRepository;
import jakarta.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.UUID;

/**
 * Service responsible for periodically syncing popularity data from Redis to the database.
 *
 * This service extracts popularity data stored in Redis, aggregates it, and updates the records
 * in the SQL database. After a successful update to the database, the corresponding keys in
 * Redis are deleted to free up space and avoid duplication.
 *
 * The popularity data in Redis is expected to follow a specific key format:
 * `popularity:{country}:{modeId}:{gameId}`, where:
 * - `{country}` is the country code.
 * - `{modeId}` is the UUID of the game mode.
 * - `{gameId}` is the UUID of the game.
 *
 * The value associated with each key in Redis is assumed to represent a numeric count.
 * This service attempts to merge the count from Redis with existing records in the database.
 *
 * If errors occur during processing, such as malformed keys, invalid UUIDs or counts, or
 * connectivity issues with Redis or the database, those errors are logged, and the processing
 * of the affected key is skipped. This ensures that other valid keys continue to be processed.
 *
 * Annotations:
 * - `@Service`: Marks this class as a Spring service component.
 * - `@RequiredArgsConstructor`: Generates a constructor with required arguments for the
 *   final fields.
 * - `@Scheduled`: Configures a periodic task to run every minute (`fixedRate = 60000`).
 */
@Service
@RequiredArgsConstructor
public class RedisFlushService {

    private static final String REDIS_POPULARITY_KEY_PATTERN = "popularityRepository:%s:*:%s";

    @Nullable
    private final StringRedisTemplate redisTemplate;
    private final PopularityCountRepository popularityCountRepository;

    @Scheduled(fixedRate = 600000) // Every 10 minutes
    public void flushRedisToDatabase() {
        if (redisTemplate == null) {
            System.err.println("Redis is not configured.");
            return;
        }
        try {
            Set<String> keys = redisTemplate.keys(REDIS_POPULARITY_KEY_PATTERN);
            if (keys == null || keys.isEmpty()) {
                System.out.println("No popularityRepository keys found in Redis to flush.");
                return;
            }
            for (String key : keys) {
                String[] parts = key.split(":");
                if (parts.length != 4) {
                    System.err.println("Skipping malformed Redis key: " + key);
                    continue;
                }
                String country = parts[1];
                UUID modeId;
                UUID gameId;
                try {
                    modeId = UUID.fromString(parts[2]);
                    gameId = UUID.fromString(parts[3]);
                } catch (IllegalArgumentException e) {
                    System.err.println("Invalid UUID in Redis key: " + key);
                    continue;
                }

                String value = redisTemplate.opsForValue().get(key);
                if (value == null) continue;

                long count;
                try {
                    count = Long.parseLong(value);
                } catch (NumberFormatException e) {
                    System.err.println("Invalid count value in Redis for key: " + key);
                    continue;
                }

                PopularityCount entity = popularityCountRepository
                        .findById(new PopularityCount.PopularityCountId(country, modeId, gameId))
                        .orElseGet(() -> {
                            PopularityCount p = new PopularityCount();
                            p.setCountryCode(country);
                            p.setGameModeId(modeId);
                            p.setGameId(gameId);
                            p.setCount(0);
                            return p;
                        });
                entity.setCount(entity.getCount() + count);
                popularityCountRepository.save(entity);
                redisTemplate.delete(key);

                // ADD: Success logging for monitoring
                System.out.printf("Flushed and deleted Redis key %s (country=%s, modeId=%s, gameId=%s, countDelta=%d) New DB count=%d%n",
                        key, country, modeId, gameId, count, entity.getCount());
            }
        } catch (RedisConnectionFailureException e) {
            System.err.println("Redis connection failure: " + e.getMessage());
        } catch (DataAccessException e) {
            System.err.println("Redis data access error: " + e.getMessage());
        }
    }
}