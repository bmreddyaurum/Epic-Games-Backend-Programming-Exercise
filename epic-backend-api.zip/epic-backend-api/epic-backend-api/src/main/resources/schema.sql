CREATE TABLE if not exists countries
(
    code CHAR(2) PRIMARY KEY,
    name VARCHAR(64) NOT NULL
);

CREATE TABLE if not exists users
(
    id           UUID PRIMARY KEY,
    username     VARCHAR(64) UNIQUE NOT NULL,
    country_code CHAR(2) REFERENCES countries (code)
);

CREATE TABLE if not exists games
(
    id          UUID PRIMARY KEY,
    name        VARCHAR(50) NOT NULL,
    description VARCHAR(128),
    country_code CHAR(2) REFERENCES countries (code),
    max_players INT
);


CREATE TABLE if not exists game_modes
(
    id          UUID PRIMARY KEY,
    game_id     UUID REFERENCES games (id),
    mode_name   VARCHAR(64) NOT NULL, -- e.g. "Battle Royale", "Duo"
    max_players INT,
    country_code CHAR(2) REFERENCES countries (code),
    description VARCHAR(128),
    UNIQUE (game_id, mode_name)
);

CREATE TABLE if not exists plays
(
    id           UUID PRIMARY KEY,
    user_id      UUID REFERENCES users (id) ,
    game_id UUID REFERENCES games (id),
    game_mode_id UUID REFERENCES game_modes (id),
    country_code CHAR(2) REFERENCES countries (code),
    timestamp    TIMESTAMP NOT NULL
);

CREATE TABLE if not exists popularity_counts
(
    country_code CHAR(2),
    game_mode_id UUID,
    game_id      UUID,
    count        BIGINT,
    PRIMARY KEY (country_code, game_mode_id),
    FOREIGN KEY (country_code) REFERENCES countries (code),
    FOREIGN KEY (game_mode_id) REFERENCES game_modes (id),
    FOREIGN KEY (game_id) REFERENCES games (id)
);